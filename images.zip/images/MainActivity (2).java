package com.threensimpleapps.birthdayphotoframes.activities;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.threensimpleapps.birthdayphotoframes.BuildConfig;
import com.threensimpleapps.birthdayphotoframes.R;
import com.threensimpleapps.birthdayphotoframes.classes.ConnectionDetector;
import com.threensimpleapps.birthdayphotoframes.cropclasses.CropImageActivity;
import com.threensimpleapps.birthdayphotoframes.cropclasses.CropUtil;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity {

    private int screenWidth, screenHeight;
    private Toolbar toolbar;
    private Button camera_button,gallery_button,viewfiles_button;
    private StateListDrawable states;

    private int camera_ReqCode = 121, gallery_ReqCode = 212;
    private boolean permission = false;
    private final int CAMERA_RESULT = 101, GALLERY_RESULT = 102;
    private String mCurrentPhotoPath;
    private File sdImageMainDirectory;

    private ConnectionDetector cd;
    private boolean isInternetPresent = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cd = new ConnectionDetector(getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();

        File root = new File(Environment
                .getExternalStorageDirectory()
                + File.separator + "myDir" + File.separator);
        if (!root.exists()) {
            root.mkdirs();
        }
        sdImageMainDirectory = new File(root, "myPicName.jpg");

        screenWidth = getResources().getDisplayMetrics().widthPixels;
        screenHeight = getResources().getDisplayMetrics().heightPixels;

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RelativeLayout option_lay_out=(RelativeLayout)findViewById(R.id.option_lay_out);
        option_lay_out.getLayoutParams().height=(screenHeight*60)/100;


        camera_button=(Button)findViewById(R.id.camera_button);
        camera_button.getLayoutParams().width=screenWidth/6;
        camera_button.getLayoutParams().height=screenWidth/6;

        states = new StateListDrawable();
        states.addState(new int[] {},
                getResources().getDrawable(R.drawable.ic_camera));
        camera_button.setBackgroundDrawable(states);
        camera_button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED) {
                    dispatchTakenPictureIntent();
                } else {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                        //Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                    }
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_RESULT);
                }

            }
        });

        gallery_button=(Button)findViewById(R.id.gallery_button);
        gallery_button.getLayoutParams().width=screenWidth/6;
        gallery_button.getLayoutParams().height=screenWidth/6;

        states = new StateListDrawable();
        states.addState(new int[] {},
                getResources().getDrawable(R.drawable.ic_gallery));
        gallery_button.setBackgroundDrawable(states);
        gallery_button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(MainActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    GalleryPictureIntent();
                } else {
                    if (shouldShowRequestPermissionRationale(READ_EXTERNAL_STORAGE)) {
                        //Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                    }
                    requestPermissions(new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, GALLERY_RESULT);
                }
            }
        });

        viewfiles_button=(Button)findViewById(R.id.viewfiles_button);
        viewfiles_button.getLayoutParams().width=screenWidth/6;
        viewfiles_button.getLayoutParams().height=screenWidth/6;
        viewfiles_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Albums_Activity.class));
            }
        });

        states = new StateListDrawable();
        states.addState(new int[] {},
                getResources().getDrawable(R.drawable.ic_view_files));
        viewfiles_button.setBackgroundDrawable(states);


        if(isInternetPresent)
        {
            displayAd();
        }
    }


    private void dispatchTakenPictureIntent() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Ensure that there's a camera activity to handle the intent
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    return;
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    Uri photoURI = null;
                    try {
                        photoURI = FileProvider.getUriForFile(MainActivity.this,
                                BuildConfig.APPLICATION_ID + ".provider",
                                createImageFile());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(takePictureIntent, camera_ReqCode);
                }
            }
        } else {
            Uri outputFileUri = Uri.fromFile(sdImageMainDirectory);
            Intent intent3 = new Intent("android.media.action.IMAGE_CAPTURE");
            intent3.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
            // intent.putExtra("return-data", true);
            startActivityForResult(intent3, camera_ReqCode);
        }
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM), "Camera");
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file:" + image.getAbsolutePath();
        return image;
    }



    private void GalleryPictureIntent() {
        try
        {
            startActivityForResult(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), gallery_ReqCode);
        }catch (Exception e)
        {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), gallery_ReqCode);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.more) {
            if (isInternetPresent) {
                try {
                    Intent localIntent = new Intent("android.intent.action.VIEW");
                    localIntent.setData(Uri
                            .parse("market://search?q=pub:ThreeN+Simple+Apps"));
                    MainActivity.this.startActivity(localIntent);
                } catch (Exception e) {
                    viewInBrowser(MainActivity.this, "https://play.google.com/store/apps/developer?id=ThreeN+Simple+Apps");
                }
            } else
                No_Internet_Dialouge();
            return true;
        }
        if (id == R.id.like) {
            if (isInternetPresent) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=" + getPackageName())));
                } catch (Exception e) {
                    viewInBrowser(MainActivity.this, "https://play.google.com/store/apps/details?id=" + getPackageName());
                }
            } else
                No_Internet_Dialouge();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void No_Internet_Dialouge()
    {

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(
                MainActivity.this);
        mBuilder.setMessage("Sorry No Internet Connection please try again later");
        mBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        });
        mBuilder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this,"Please connect internet....",Toast.LENGTH_SHORT).show();

                    }
                });
        mBuilder.create();
        mBuilder.show();
    }

    private void viewInBrowser(MainActivity mainActivity, String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (null != intent.resolveActivity(mainActivity.getPackageManager())) {
            mainActivity.startActivity(intent);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_RESULT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakenPictureIntent();
            } else {
                //Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                permssiondialog();
            }
        }
        if (requestCode == GALLERY_RESULT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                GalleryPictureIntent();
            } else {
                // Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                permssiondialog();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }




    private void permssiondialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(false);
        builder.setTitle("App requires Storage permissions to work perfectly..!");
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                permission = true;
                dialog.dismiss();
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("Exit",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == camera_ReqCode && resultCode == RESULT_OK) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Uri imageUri;
                try {
                    imageUri = Uri.parse(mCurrentPhotoPath);
                } catch (Exception e) {
                    e.printStackTrace();
                    imageUri = Uri.parse(mCurrentPhotoPath);
                }

                CropUtil.picpath = imageUri;
                Intent intent = new Intent(MainActivity.this, CropImageActivity.class);
                intent.putExtra("status", getResources().getString(R.string.image_status));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else {
                CropUtil.picpath = Uri.fromFile(sdImageMainDirectory);
                Intent intent = new Intent(MainActivity.this, CropImageActivity.class);
                intent.putExtra("status", getResources().getString(R.string.image_status));
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }


        }else if (requestCode == gallery_ReqCode && resultCode == RESULT_OK
                && null != data) {
            Uri selectedImage = data.getData();
            CropUtil.picpath = selectedImage;

            Intent intent = new Intent(MainActivity.this, CropImageActivity.class);
            intent.putExtra("status", getResources().getString(R.string.image_status));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
    }

    private void displayAd() {
        try {
            RelativeLayout bannerspace = (RelativeLayout) findViewById(R.id.bannerspace);
            bannerspace.getLayoutParams().height = SplashScreen.dpToPx(5);

            LinearLayout linearlay = (LinearLayout) findViewById(R.id.banner_lay);
            linearlay.setVisibility(View.VISIBLE);
            // Create an ad.
            AdView adView = new AdView(MainActivity.this);
            adView.setAdSize(AdSize.BANNER);
            adView.setAdUnitId(getResources().getString(R.string.banner_ad_id));

            // Add the AdView to the view hierarchy. The view will have no size
            // until the ad is loaded.
            FrameLayout linearLayout = (FrameLayout) findViewById(R.id.banner);
            linearLayout.addView(adView);

            // Create an ad request. Check logcat output for the hashed device ID to
            // get test ads on a physical device.
            AdRequest adRequest = new AdRequest.Builder().build();

            // Start loading the ad in the background.
            adView.loadAd(adRequest);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(
                MainActivity.this);
        mBuilder.setTitle("Rate US");
        mBuilder.setMessage("Thank You For Using Our Application Please Give Us Your Rating and Review.");
        mBuilder.setPositiveButton("RATE US", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (isInternetPresent) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("market://details?id=" + getPackageName())));
                    } catch (Exception e) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" +  getPackageName())));

                    }

                }
                else
                {
                    No_Internet_Dialouge();
                }
                dialog.dismiss();

            }
        });
        mBuilder.setNegativeButton("EXIT",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.this.finish();
                        dialog.dismiss();


                    }
                });
        mBuilder.create();
        mBuilder.show();
    }
}
