package com.katamapps.christmasphotoframes.activities;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.InterstitialAd;
import com.katamapps.christmasphotoframes.R;
import com.katamapps.christmasphotoframes.classes.ImagePath_MarshMallow;
import com.katamapps.christmasphotoframes.classes.InternetConnection;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.katamapps.christmasphotoframes.classes.Model_Class;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity {

    private int screen_width, screen_height;

    private final int CAMERA_RESULT = 101, GALLERY_RESULT = 102;
    //gallery and Camera
    private int camera_ReqCode = 121, gallery_ReqCode = 212;
    private Uri capturedFileUri;
    private boolean view_bl = false;
    private String getImageUrl = "";
    //u_crop
    private String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";


    private InternetConnection cd;
    private boolean isInternetPresent;
    private AdView adView;
    private InterstitialAd mInterstitialAd;


    //own ads
    //the URL having the json data
    private static final String JSON_URL = "https://github.com/VattipalliSridhar/News/raw/master/ownads/ownads_link.json";
    //the hero list where we will store all the hero objects after parsing json
    private List<Model_Class> ownads_list, exit_list;
    public static List<Model_Class> more_app_list;
    private RecyclerView more_app_recycler_view;

    //exit screen
    private Dialog customDialog;
    private int dwidth, dheight, dialogWidth, dialogHeight;
    private RelativeLayout exit_top_layout, exit_image_layout, exit_exit_layout, exit_main_layout;
    private ImageView frstImage, secndImage, thirdImage, fourImage, fiveImage, sixImage;
    private TextView frstText, secndText, thirdText, fourText;
    private Button exit_close_button, exit_button;
    private Animation animation;
    private int animation_xml[] = {R.anim.wobble, R.anim.wobble_zoom, R.anim.zoom_in_out, R.anim.exit_anim};
    private Random random = new Random();
    private ArrayList<String> packagesList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        cd = new InternetConnection(this);
        isInternetPresent = cd.isConnectingToInternet();

        if (isInternetPresent) {
            ownads_list = new ArrayList<>();
            ownads_list.clear();

            more_app_list = new ArrayList<>();
            more_app_list.clear();

            exit_list = new ArrayList<>();
            exit_list.clear();

            packagesList.clear();
            mInterstitialAd_setup();
            displayAd();
            loadAdsList();
        }


        Toolbar toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);

        screen_width = this.getResources().getDisplayMetrics().widthPixels;
        screen_height = this.getResources().getDisplayMetrics().heightPixels;


        ImageView iv_camera = (ImageView) findViewById(R.id.iv_camera);
        iv_camera.getLayoutParams().height = (screen_width * 20) / 100;
        iv_camera.getLayoutParams().width = (screen_width * 20) / 100;
        iv_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED) {
                    dispatchTakenPictureIntent();
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                            //Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_RESULT);
                    }
                }


                if (isInternetPresent) {
                    mInterstitialAd_setup();
                }

            }
        });

        ImageView iv_myImages = (ImageView) findViewById(R.id.iv_myImages);
        iv_myImages.getLayoutParams().height = (screen_width * 20) / 100;
        iv_myImages.getLayoutParams().width = (screen_width * 20) / 100;
        iv_myImages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view_bl = true;
                if (ContextCompat.checkSelfPermission(MainActivity.this, READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(MainActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                   // startActivity(new Intent(MainActivity.this, Albums_Activity.class));

                    if (isInternetPresent) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                        } else {
                            Log.d("TAG", "The interstitial wasn't loaded yet.");
                            startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                        }
                        mInterstitialAd.setAdListener(new AdListener() {
                            @Override
                            public void onAdClosed() {
                                // Load the next interstitial.
                                mInterstitialAd_setup();
                                startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                            }
                        });
                    } else {
                        startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                    }
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(READ_EXTERNAL_STORAGE)) {
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, GALLERY_RESULT);
                    }
                }
            }
        });

        ImageView iv_gallery = (ImageView) findViewById(R.id.iv_gallery);
        iv_gallery.getLayoutParams().height = (screen_width * 20) / 100;
        iv_gallery.getLayoutParams().width = (screen_width * 20) / 100;
        iv_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(MainActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    GalleryPictureIntent();
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(READ_EXTERNAL_STORAGE)) {
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, GALLERY_RESULT);
                    }
                }

                if (isInternetPresent) {
                    mInterstitialAd_setup();
                }
            }
        });


        ImageView moreapps = (ImageView) findViewById(R.id.moreapps);
        moreapps.getLayoutParams().height = (screen_width * 20) / 100;
        moreapps.getLayoutParams().width = (screen_width * 20) / 100;
        moreapps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isInternetPresent) {
                    try {
                        Intent localIntent = new Intent("android.intent.action.VIEW");
                        localIntent.setData(Uri
                                .parse("market://search?q=pub:katamapps"));
                        MainActivity.this.startActivity(localIntent);
                    } catch (Exception e) {
                        viewInBrowser(MainActivity.this, "https://play.google.com/store/apps/developer?id=katamapps");
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please connect internet..", Toast.LENGTH_LONG).show();
                }

            }
        });

        ImageView rateus = (ImageView) findViewById(R.id.rateus);
        rateus.getLayoutParams().height = (screen_width * 20) / 100;
        rateus.getLayoutParams().width = (screen_width * 20) / 100;
        rateus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isInternetPresent) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("market://details?id=" + getPackageName())));
                    } catch (Exception e) {
                        viewInBrowser(MainActivity.this, "https://play.google.com/store/apps/details?id=" + getPackageName());
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please connect internet..", Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    private void mInterstitialAd_setup() {
        mInterstitialAd = new InterstitialAd(MainActivity.this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_Ad_id_save));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    private void viewInBrowser(MainActivity mainActivity, String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (null != intent.resolveActivity(mainActivity.getPackageManager())) {
            mainActivity.startActivity(intent);
        }
    }

    private void dispatchTakenPictureIntent() {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                StrictMode.class.getMethod("disableDeathOnFileUriExposure", new Class[0]).invoke(null, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        capturedFileUri = getOutputMediaFileUri(MainActivity.this);
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra("output", capturedFileUri);
        startActivityForResult(intent, camera_ReqCode);
    }

    private Uri getOutputMediaFileUri(Context context) {
        File mediaStorageDir = new File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Camera");
        if (!mediaStorageDir.exists() && mediaStorageDir.mkdir()) {
            Log.e("Create Directory", "Main Directory Created : " + mediaStorageDir);
        }
        return Uri.fromFile(new File(mediaStorageDir.getPath() + File.separator + "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(new Date()) + ".jpg"));
    }


    private void GalleryPictureIntent() {
        try {
            startActivityForResult(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), gallery_ReqCode);
        } catch (Exception e) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), gallery_ReqCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_RESULT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakenPictureIntent();
            } else {
                //Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                permission_dialog();
            }
        }
        if (requestCode == GALLERY_RESULT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                if (view_bl == true) {
                    if (isInternetPresent) {
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                        } else {
                            Log.d("TAG", "The interstitial wasn't loaded yet.");
                            startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                        }
                        mInterstitialAd.setAdListener(new AdListener() {
                            @Override
                            public void onAdClosed() {
                                // Load the next interstitial.
                                mInterstitialAd_setup();
                                startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                            }
                        });
                    } else {
                        startActivity(new Intent(MainActivity.this, Albums_Activity.class));
                    }
                } else {
                    GalleryPictureIntent();
                }


            } else {
                // Toast.makeText(getApplicationContext(), "Permission Needed.", Toast.LENGTH_LONG).show();
                permission_dialog();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void permission_dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(false);
        builder.setTitle("App requires Storage permissions to work perfectly..!");
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("Exit",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        builder.show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == gallery_ReqCode) {
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    startCropActivity(data.getData());
                } else {
                    //Toast.makeText(SampleActivity.this, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show();
                }
            }
            if (requestCode == camera_ReqCode) {
                if (Build.VERSION.SDK_INT > 22) {
                    this.getImageUrl = ImagePath_MarshMallow.getPath(this, this.capturedFileUri);
                } else {
                    this.getImageUrl = this.capturedFileUri.getPath();
                }
                startCropActivity(this.capturedFileUri);
            } else if (requestCode == UCrop.REQUEST_CROP) {
                handleCropResult(data);
            }
        }
        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }


    private void startCropActivity(@NonNull Uri uri) {
        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;
        destinationFileName += ".png";
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        //UCrop.of(data, fromFile).withOptions(options).withAspectRatio(1.0f, 1.0f).start(this);
        uCrop = basisConfig(uCrop);
        uCrop = advancedConfig(uCrop);
        uCrop.withOptions(options).start(MainActivity.this);
    }

    private UCrop basisConfig(@NonNull UCrop uCrop) {

        return uCrop;
    }


    private UCrop advancedConfig(@NonNull UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();
        return uCrop.withOptions(options);
    }

    private void handleCropResult(@NonNull Intent result) {
        result.setAction(Intent.ACTION_GET_CONTENT);
        result.addCategory(Intent.CATEGORY_OPENABLE);
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null) {
            Log.e("msg", "" + resultUri);
            try {
                Intent intent = new Intent(MainActivity.this, Frames_Activity.class);
                intent.putExtra("imageUri", resultUri.toString());
                startActivity(intent);

                if (isInternetPresent) {
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();
                    } else {
                        Log.d("TAG", "The interstitial wasn't loaded yet.");
                    }
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(MainActivity.this, "Cannot retrieve cropped image", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            Log.e("I am in ", "handleCropError: ", cropError);
            Toast.makeText(MainActivity.this, cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "Cannot retrieve cropped image", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString string = new SpannableString(menu.getItem(i).getTitle().toString());
            string.setSpan(new ForegroundColorSpan(Color.BLACK), 0, string.length(), 0);
            item.setTitle(string);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.privacy_action) {
            startActivity(new Intent(MainActivity.this, PrivacyActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);

    }


    private void displayAd() {
        try {

            RelativeLayout banner_ads_layout = (RelativeLayout) findViewById(R.id.banner_ads_layout);
            banner_ads_layout.setVisibility(View.VISIBLE);
            adView = findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);
        } catch (Exception e) {

        }
    }

    /**
     * Called when leaving the activity
     */
    @Override
    public void onPause() {
        if (isInternetPresent) {
            if (adView != null) {
                adView.pause();
            }
        }

        super.onPause();
    }

    /**
     * Called when returning to the activity
     */
    @Override
    public void onResume() {
        super.onResume();
        if (isInternetPresent) {
            if (adView != null) {
                adView.resume();
            }
        }

    }

    /**
     * Called before the activity is destroyed
     */
    @Override
    public void onDestroy() {
        if (isInternetPresent) {
            if (adView != null) {
                adView.destroy();
            }
        }

        super.onDestroy();
    }


    private void loadAdsList() {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, JSON_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {
                            //getting the whole json object from the response
                            JSONObject obj = new JSONObject(response);

                            //we have the array named hero inside the object
                            //so here we are getting that json array
                            JSONArray heroArray = obj.getJSONArray("sample");

                            //now looping through all the elements of the json array
                            for (int i = 0; i < heroArray.length(); i++) {
                                //getting the json object of the particular index inside the array
                                JSONObject ownAdsObject = heroArray.getJSONObject(i);

                                //creating a hero object and giving them the values from json object
                                Model_Class modelClass = new Model_Class(ownAdsObject.getString("app_name"), ownAdsObject.getString("app_url"), ownAdsObject.getString("app_icon"));

                                //adding the hero to herolist
                                ownads_list.add(modelClass);
                            }
                            Log.e("msg", "" + ownads_list.size());
                            // Toast.makeText(MainActivity.this,"Ads Loaded",Toast.LENGTH_SHORT).show();

                            if (ownads_list.size() > 0) {
                                ArrayList<Model_Class> tempList = new ArrayList<Model_Class>();

                                packagesList = getInstalledApps();
                                for (int i = 0; i < ownads_list.size(); i++) {
                                    String appname = ownads_list.get(i).getApp_url();
                                    String[] names = appname.split("=");

                                    appname = names[1];

                                    if (!packagesList.contains(appname)) {
                                        tempList.add(ownads_list.get(i));

                                    }
                                }

                                exit_list.clear();
                                exit_list.addAll(tempList);

                                more_app_list.clear();
                                more_app_list.addAll(tempList);
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);


    }

    private ArrayList<String> getInstalledApps() {
        ArrayList<String> packList = new ArrayList<String>();

        List<PackageInfo> packs = getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < packs.size(); i++) {
            PackageInfo p = packs.get(i);
            if ((!isSystemPackage(p))) {
                String appName = p.applicationInfo.loadLabel(getPackageManager()).toString();
                String packgname = p.packageName;
                Log.e("       PackageName   ", " info  " + packgname);
                packList.add(packgname);
            }
        }
        return packList;
    }

    private boolean isSystemPackage(PackageInfo pkgInfo) {
        return ((pkgInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
    }

    private void exit_screen() {
        animation = AnimationUtils.loadAnimation(getApplicationContext(), animation_xml[random.nextInt(4)]);
        //animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.exit_anim);
        customDialog = new Dialog(MainActivity.this);
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.exit_screen);

        dwidth = getResources().getDisplayMetrics().widthPixels;
        dheight = getResources().getDisplayMetrics().heightPixels;

        exit_main_layout = (RelativeLayout) customDialog.findViewById(R.id.exit_main_layout);
        exit_main_layout.getLayoutParams().height = (dheight * 75) / 100;
        exit_main_layout.getLayoutParams().width = (dwidth - (dwidth / 10));

        exit_top_layout = (RelativeLayout) customDialog.findViewById(R.id.exit_top_layout);
        exit_top_layout.getLayoutParams().height = (dheight * 10) / 100;

        exit_image_layout = (RelativeLayout) customDialog.findViewById(R.id.exit_image_layout);
        exit_image_layout.getLayoutParams().height = (dheight * 50) / 100;

        exit_exit_layout = (RelativeLayout) customDialog.findViewById(R.id.exit_exit_layout);
        exit_exit_layout.getLayoutParams().height = (dheight * 15) / 100;

        exit_close_button = (Button) customDialog.findViewById(R.id.exit_close_button);
        exit_close_button.getLayoutParams().height = (dwidth) / 10;
        exit_close_button.getLayoutParams().width = (dwidth) / 10;


        frstImage = (ImageView) customDialog.findViewById(R.id.frstImage);
        frstImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        frstImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        secndImage = (ImageView) customDialog.findViewById(R.id.secndImage);
        secndImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        secndImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        thirdImage = (ImageView) customDialog.findViewById(R.id.thirdImage);
        thirdImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        thirdImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        fourImage = (ImageView) customDialog.findViewById(R.id.fourImage);
        fourImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        fourImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        fiveImage = (ImageView) customDialog.findViewById(R.id.fiveImage);
        fiveImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        fiveImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        sixImage = (ImageView) customDialog.findViewById(R.id.sixImage);
        sixImage.getLayoutParams().width = (int) (screen_width * 25) / 100;
        sixImage.getLayoutParams().height = (int) (screen_width * 25) / 100;

        TextView firstText = (TextView) customDialog
                .findViewById(R.id.frstText);
        TextView secondText = (TextView) customDialog
                .findViewById(R.id.secndText);
        TextView thirdText = (TextView) customDialog
                .findViewById(R.id.thirdText);
        TextView fourthText = (TextView) customDialog
                .findViewById(R.id.fourText);

        TextView fiveText = (TextView) customDialog
                .findViewById(R.id.fiveText);

        TextView sixText = (TextView) customDialog
                .findViewById(R.id.sixText);

        if (exit_list != null && exit_list.size() >= 6) {
            firstText.setText(exit_list.get(0).getApp_name());
            firstText.setSelected(true);
            secondText.setText(exit_list.get(1).getApp_name());
            secondText.setSelected(true);
            thirdText.setText(exit_list.get(2).getApp_name());
            thirdText.setSelected(true);
            fourthText.setText(exit_list.get(3).getApp_name());
            fourthText.setSelected(true);

            fiveText.setText(exit_list.get(4).getApp_name());
            fiveText.setSelected(true);

            sixText.setText(exit_list.get(5).getApp_name());
            sixText.setSelected(true);

        }

        if (exit_list != null && exit_list.size() >= 6) {

            Glide.with(getApplicationContext()).load(exit_list.get(0).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(frstImage);
            Glide.with(getApplicationContext()).load(exit_list.get(1).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(secndImage);
            Glide.with(getApplicationContext()).load(exit_list.get(2).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(thirdImage);
            Glide.with(getApplicationContext()).load(exit_list.get(3).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(fourImage);

            Glide.with(getApplicationContext()).load(exit_list.get(4).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(fiveImage);

            Glide.with(getApplicationContext()).load(exit_list.get(5).getApp_icon())
                    .placeholder(R.drawable.loading_icon).error(R.drawable.loading_icon)
                    .into(sixImage);


            frstImage.startAnimation(animation);
            secndImage.startAnimation(animation);
            thirdImage.startAnimation(animation);
            fourImage.startAnimation(animation);
            fiveImage.startAnimation(animation);
            sixImage.startAnimation(animation);

        }
        if (isInternetPresent && exit_list != null && exit_list.size() >= 6) {
            frstImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (exit_list != null && exit_list.size() >= 1)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(0).getApp_url())));
                }
            });

            secndImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (exit_list != null && exit_list.size() >= 2)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(1).getApp_url())));
                }
            });

            thirdImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (exit_list != null && exit_list.size() >= 3)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(2).getApp_url())));
                }
            });

            fourImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    if (exit_list != null && exit_list.size() >= 4)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(3).getApp_url())));
                }
            });

            fiveImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    if (exit_list != null && exit_list.size() >= 5)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(4).getApp_url())));
                }
            });

            sixImage.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    if (exit_list != null && exit_list.size() >= 6)
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(exit_list.get(5).getApp_url())));
                }
            });

        }
        exit_close_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog.dismiss();
            }
        });

        exit_button = (Button) customDialog.findViewById(R.id.exit_button);
        exit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.finish();
                customDialog.dismiss();
                System.exit(0);
            }
        });


        customDialog.setCancelable(false);
        customDialog.show();
    }

    @Override
    public void onBackPressed() {
        if (isInternetPresent) {
            exit_screen();

        } else {
            finish();
            System.exit(0);
        }
    }


}
